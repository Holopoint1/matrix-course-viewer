(function () {
  'use strict';

  const params = new URLSearchParams(location.search);
  const courseId = params.get('id');

  if (!courseId) {
    location.replace('index.html');
    return;
  }

  const els = {
    courseCode: document.getElementById('course-code'),
    courseTitle: document.getElementById('course-title'),
    screenList: document.getElementById('screen-list'),
    progressBar: document.getElementById('progress-bar'),
    progressCompleted: document.getElementById('progress-completed'),
    progressTotal: document.getElementById('progress-total'),
    progressPercent: document.getElementById('progress-percent'),
    certificateCta: document.getElementById('certificate-cta'),
    certificateLink: document.getElementById('certificate-link'),
    screenTitle: document.getElementById('screen-title'),
    screenMeta: document.getElementById('screen-meta'),
    screenStage: document.getElementById('screen-stage'),
    prevBtn: document.getElementById('prev-btn'),
    completeBtn: document.getElementById('complete-btn')
  };

  let course = null;
  let currentIndex = 0;
  const docCache = new Map();

  /* ---------- Time tracker ---------- */
  const timeTracker = (function () {
    const SAVE_INTERVAL_MS = 15000;
    const KEY_PREFIX = 'matrix-lms:time:';
    let trackingCourseId = null;
    let trackingScreenId = null;
    let segmentStartedAt = null;
    let intervalId = null;

    function start(cId, sId) {
      stop();
      trackingCourseId = cId;
      trackingScreenId = sId;
      if (document.visibilityState === 'visible') {
        segmentStartedAt = Date.now();
      }
      intervalId = setInterval(flush, SAVE_INTERVAL_MS);
    }
    function stop() {
      if (intervalId) clearInterval(intervalId);
      flush();
      trackingCourseId = trackingScreenId = segmentStartedAt = intervalId = null;
    }
    function flush() {
      if (!segmentStartedAt || !trackingCourseId || !trackingScreenId) return;
      const elapsedSec = Math.floor((Date.now() - segmentStartedAt) / 1000);
      if (elapsedSec < 1) return;
      addSeconds(trackingCourseId, trackingScreenId, elapsedSec);
      segmentStartedAt = Date.now();
    }
    function addSeconds(cId, sId, secs) {
      try {
        const key = KEY_PREFIX + cId;
        const data = JSON.parse(localStorage.getItem(key) || '{}');
        data[sId] = (data[sId] || 0) + secs;
        localStorage.setItem(key, JSON.stringify(data));
      } catch (_) {}
    }
    document.addEventListener('visibilitychange', () => {
      if (!trackingCourseId) return;
      if (document.visibilityState === 'visible') {
        segmentStartedAt = Date.now();
      } else {
        flush();
        segmentStartedAt = null;
      }
    });
    window.addEventListener('beforeunload', flush);
    window.addEventListener('pagehide', flush);
    return { start, stop, flush };
  })();

  init();

  async function init() {
    try {
      const res = await fetch('data/courses.json');
      const data = await res.json();
      course = data.courses.find((c) => c.id === courseId);
      if (!course) throw new Error('Course not found: ' + courseId);
      if (window.Gamify) {
        await window.Gamify.init();
        window.Gamify.trackCourseVisit(courseId);
      }
    } catch (err) {
      els.screenStage.innerHTML = '<p class="stage-loading">Could not load course. ' + err.message + '</p>';
      return;
    }

    document.title = course.title + ' | Matrix Course Viewer';
    els.courseCode.textContent = course.code;
    els.courseTitle.textContent = course.title;
    els.progressTotal.textContent = course.screens.length;

    if (course.certificate && course.certificate.enabled) {
      els.certificateLink.href = 'certificate.html?id=' + encodeURIComponent(course.id);
    }

    renderSidebar();
    renderProgress();

    const startIndex = restoreLastIndex();
    showScreen(startIndex);

    els.prevBtn.addEventListener('click', () => {
      if (currentIndex > 0) showScreen(currentIndex - 1);
    });
    els.completeBtn.addEventListener('click', () => {
      const screen = course.screens[currentIndex];
      if (isComplete(screen.id)) {
        setComplete(screen.id, false);
        updateCompleteButton();
      } else {
        setComplete(screen.id, true);
        if (currentIndex < course.screens.length - 1) {
          showScreen(currentIndex + 1);
        } else {
          updateCompleteButton();
        }
      }
    });
  }

  function renderSidebar() {
    els.screenList.innerHTML = '';
    let lastSection = null;
    let sectionPos = 0;
    course.screens.forEach((screen, idx) => {
      const section = window.Gamify ? window.Gamify.inferSection(screen) : 'all';
      if (section !== lastSection) {
        lastSection = section;
        sectionPos = 0;
        const header = document.createElement('li');
        header.className = 'section-header section-' + section;
        header.innerHTML = `<span class="section-dot"></span><span class="section-label">${sectionTitle(section)}</span>`;
        els.screenList.appendChild(header);
      }
      sectionPos += 1;
      const li = document.createElement('li');
      li.className = 'screen-item';
      li.dataset.index = String(idx);
      if (screen.missing) li.classList.add('missing');
      if (isComplete(screen.id)) li.classList.add('completed');
      li.innerHTML = `
        <button type="button" class="screen-checkbox" aria-label="Toggle complete"></button>
        <span class="screen-title">
          <span class="screen-num">${sectionPos}</span>
          <span class="screen-title-text">${escapeHtml(screen.title)}</span>
        </span>
        <span class="screen-type-dot ${screen.type}" title="${escapeHtml(screen.type)}"></span>
      `;
      li.addEventListener('click', () => showScreen(idx));
      li.querySelector('.screen-checkbox').addEventListener('click', (ev) => {
        ev.stopPropagation();
        toggleComplete(screen.id);
      });
      els.screenList.appendChild(li);
    });
  }

  function sectionTitle(section) {
    return ({
      intro: 'Welcome',
      bronze: 'Bronze',
      silver: 'Silver',
      gold: 'Gold',
      assessment: 'Assessment',
      homework: 'Homework',
      project: 'Project'
    })[section] || section;
  }

  function showScreen(idx) {
    currentIndex = idx;
    persistLastIndex(idx);
    const screen = course.screens[idx];

    els.screenList.querySelectorAll('.screen-item.active').forEach((node) => node.classList.remove('active'));
    const active = els.screenList.querySelector(`.screen-item[data-index="${idx}"]`);
    if (active) {
      active.classList.add('active');
      active.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    els.screenTitle.textContent = screen.title;
    els.screenMeta.textContent = formatMeta(screen);
    els.prevBtn.disabled = idx === 0;
    updateCompleteButton();

    timeTracker.start(courseId, screen.id);
    renderStage(screen);
  }

  function updateCompleteButton() {
    const screen = course.screens[currentIndex];
    const last = currentIndex === course.screens.length - 1;
    const done = isComplete(screen.id);
    if (done) {
      els.completeBtn.textContent = 'Mark incomplete';
      els.completeBtn.classList.remove('btn-primary');
      els.completeBtn.classList.add('btn-secondary');
    } else {
      els.completeBtn.textContent = last ? 'Mark complete' : 'Mark complete & next';
      els.completeBtn.classList.remove('btn-secondary');
      els.completeBtn.classList.add('btn-primary');
    }
  }

  function renderStage(screen) {
    const stage = els.screenStage;
    stage.innerHTML = '';

    if (screen.missing) {
      stage.innerHTML = `
        <div class="stage-missing">
          <span class="badge">Asset not yet available</span>
          <h2>${escapeHtml(screen.title)}</h2>
          <p>This screen is defined in the course outline but the source file <code>${escapeHtml(filename(screen.src))}</code> has not yet been added.</p>
        </div>`;
      return;
    }

    switch (screen.type) {
      case 'image':
        renderImage(stage, screen);
        return;
      case 'youtube':
        renderYoutube(stage, screen);
        return;
      case 'pdf':
        renderIframe(stage, screen.src);
        return;
      case 'html':
        renderHtmlContent(stage, screen);
        return;
      case 'document':
        renderDocument(stage, screen);
        return;
      case 'powerpoint':
      case 'spreadsheet':
        renderDownload(stage, screen);
        return;
      default:
        stage.innerHTML = `<p class="stage-loading">Unsupported screen type: ${escapeHtml(screen.type)}</p>`;
    }
  }

  function renderImage(stage, screen) {
    const wrap = document.createElement('div');
    wrap.className = 'stage-image';
    const img = document.createElement('img');
    img.src = screen.src;
    img.alt = screen.title;
    wrap.appendChild(img);
    stage.appendChild(wrap);
  }

  function renderYoutube(stage, screen) {
    const id = extractYoutubeId(screen.src);
    if (!id) {
      stage.innerHTML = `<p class="stage-loading">Could not parse YouTube URL: ${escapeHtml(screen.src)}</p>`;
      return;
    }
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${id}`;
    iframe.title = screen.title;
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    iframe.allowFullscreen = true;
    stage.appendChild(iframe);
  }

  function renderIframe(stage, src) {
    const iframe = document.createElement('iframe');
    iframe.src = src;
    iframe.referrerPolicy = 'no-referrer';
    stage.appendChild(iframe);
  }

  async function renderHtmlContent(stage, screen) {
    if (screen.external || /^https?:/i.test(screen.src || '')) {
      return renderIframe(stage, screen.src);
    }
    const wrap = document.createElement('div');
    wrap.className = 'stage-doc';
    wrap.innerHTML = '<div class="stage-doc-inner"><p class="stage-loading">Loading&hellip;</p></div>';
    stage.appendChild(wrap);
    const inner = wrap.querySelector('.stage-doc-inner');
    try {
      const res = await fetch(screen.src);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const text = await res.text();
      const doc = new DOMParser().parseFromString(text, 'text/html');
      const pageEl = doc.querySelector('.page');
      let bodyHtml = pageEl ? pageEl.innerHTML : (doc.body ? doc.body.innerHTML : text);
      bodyHtml = enhanceWorksheetHtml(bodyHtml);
      inner.innerHTML = bodyHtml;
    } catch (err) {
      /* graceful fallback: iframe the file as-is */
      wrap.remove();
      renderIframe(stage, screen.src);
    }
  }

  /* Promote pseudo-heading paragraphs ("Design brief:", "Hardware:", etc.) into real headings.
     Source text is preserved verbatim — only the tag changes. */
  function enhanceWorksheetHtml(html) {
    let parsed;
    try {
      parsed = new DOMParser().parseFromString('<!DOCTYPE html><html><body>' + html + '</body></html>', 'text/html');
    } catch (_) {
      return html;
    }
    const root = parsed.body;
    if (!root) return html;

    /* 1. Convert layout-only header tables (the "Worksheet 7 / Title / Course" strip) into a
          subdued metadata header. mammoth-rendered docs always have a small sparse table at the top. */
    Array.from(root.querySelectorAll('table')).forEach((table) => {
      const cells = Array.from(table.querySelectorAll('td, th'));
      const filled = cells
        .map((c) => (c.textContent || '').trim())
        .filter((t) => t && t.length > 0);
      const allShort = filled.every((t) => t.length < 120);
      const hasParagraphTexts = filled.some((t) => t.length >= 120);
      /* If the table is small and contains short labels (worksheet header) — convert.
         If it's a large table with long descriptive paragraphs — leave it alone. */
      if (cells.length <= 16 && filled.length <= 8 && allShort && !hasParagraphTexts) {
        const meta = parsed.createElement('div');
        meta.className = 'worksheet-header';
        meta.innerHTML = filled.map((t) => `<span>${escapeHtml(t)}</span>`).join('');
        table.replaceWith(meta);
      } else if (cells.length <= 6 && filled.length <= 4 && allShort) {
        /* Short overview table → header */
        const meta = parsed.createElement('div');
        meta.className = 'worksheet-header';
        meta.innerHTML = filled.map((t) => `<span>${escapeHtml(t)}</span>`).join('');
        table.replaceWith(meta);
      }
    });

    /* 2. Embed bare YouTube URLs as inline iframes */
    Array.from(root.querySelectorAll('a')).forEach((a) => {
      const href = a.getAttribute('href') || '';
      const m = href.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{6,})/);
      if (!m) return;
      const aText = (a.textContent || '').trim();
      if (aText !== href.trim() && !/youtu/.test(aText)) return; /* leave styled inline links */
      const wrap = parsed.createElement('div');
      wrap.className = 'inline-youtube';
      wrap.innerHTML = '<iframe src="https://www.youtube.com/embed/' + m[1] + '" allowfullscreen loading="lazy"></iframe>';
      const parent = a.parentElement;
      if (parent && parent.tagName === 'P' && (parent.textContent || '').trim() === aText) {
        parent.replaceWith(wrap);
      } else {
        a.replaceWith(wrap);
      }
    });

    /* 3. "There is no video..." → small subdued note */
    Array.from(root.querySelectorAll('p')).forEach((p) => {
      const t = (p.textContent || '').trim().toLowerCase();
      if (/^there\s+is\s+no\s+video/i.test(t)) {
        p.classList.add('no-video');
      }
    });

    /* 4. Promote pseudo-headings */
    const patterns = [
      { tag: 'h1', cls: 'doc-h1', re: /^(Homework\s*\d+|Assessment\s*\d+|Project|Assessment marking schemes)$/i },
      { tag: 'h2', cls: 'doc-section design-brief',  re: /^Design brief:?$/i },
      { tag: 'h2', cls: 'doc-section hardware',      re: /^Hardware:?$/i },
      { tag: 'h2', cls: 'doc-section software',      re: /^Software:?$/i },
      { tag: 'h2', cls: 'doc-section challenges',    re: /^Challenges:?$/i },
      { tag: 'h2', cls: 'doc-section hints',         re: /^Hints:?$/i },
      { tag: 'h2', cls: 'doc-section over-to-you',   re: /^Over to you:?$/i },
      { tag: 'h2', cls: 'doc-section risk',          re: /^Technical risk:?$/i }
    ];

    Array.from(root.querySelectorAll('p')).forEach((p) => {
      const text = (p.textContent || '').trim();
      if (!text) return;
      for (const pat of patterns) {
        if (pat.re.test(text)) {
          const tag = parsed.createElement(pat.tag);
          tag.className = pat.cls;
          tag.textContent = text;
          p.replaceWith(tag);
          return;
        }
      }
    });

    /* 5. Group consecutive bullet-like paragraphs after a hardware/topics heading into a list */
    Array.from(root.querySelectorAll('h2.hardware, h1.doc-h1')).forEach((h) => {
      const collected = [];
      let n = h.nextElementSibling;
      while (n && n.tagName === 'P') {
        const txt = (n.textContent || '').trim();
        if (!txt || txt.length > 90) break;
        if (/^(Design brief|Hardware|Software|Challenges|Hints|Over to you|Technical risk):?$/i.test(txt)) break;
        collected.push(n);
        n = n.nextElementSibling;
      }
      if (collected.length >= 2) {
        const ul = parsed.createElement('ul');
        ul.className = 'doc-list';
        collected.forEach((p) => {
          const li = parsed.createElement('li');
          li.innerHTML = p.innerHTML;
          ul.appendChild(li);
          p.remove();
        });
        h.after(ul);
      }
    });

    return root.innerHTML;
  }

  function renderDownload(stage, screen) {
    const wrap = document.createElement('div');
    wrap.className = 'stage-pptx';
    const label = screen.type === 'powerpoint' ? 'PowerPoint file' : 'Spreadsheet file';
    wrap.innerHTML = `
      <h2>${escapeHtml(screen.title)}</h2>
      <p style="color:var(--muted);max-width:520px;">${label} cannot be rendered inline in the browser. Download it to view.</p>
      <a class="btn btn-primary" href="${escapeAttr(screen.src)}" download>Download</a>
    `;
    stage.appendChild(wrap);
  }

  async function renderDocument(stage, screen) {
    if (typeof window.mammoth === 'undefined') {
      stage.innerHTML = '<p class="stage-loading">Document renderer is loading&hellip;</p>';
      await waitForMammoth();
    }
    const wrap = document.createElement('div');
    wrap.className = 'stage-doc';
    wrap.innerHTML = `
      <div class="stage-doc-toolbar">
        <a class="btn btn-secondary" href="${escapeAttr(screen.src)}" download>Download as Word</a>
      </div>
      <div class="stage-doc-inner"><p class="stage-loading">Rendering document&hellip;</p></div>`;
    stage.appendChild(wrap);
    const inner = wrap.querySelector('.stage-doc-inner');

    try {
      let html = docCache.get(screen.src);
      if (!html) {
        const res = await fetch(screen.src);
        if (!res.ok) throw new Error('Could not load file (HTTP ' + res.status + ')');
        const buf = await res.arrayBuffer();
        const result = await window.mammoth.convertToHtml({ arrayBuffer: buf });
        html = enhanceWorksheetHtml(result.value || '');
        docCache.set(screen.src, html);
      }
      inner.innerHTML = html;
    } catch (err) {
      inner.innerHTML = `<p style="color:var(--warn);">Could not render document: ${escapeHtml(err.message)}</p>`;
    }
  }

  function waitForMammoth(timeoutMs = 10000) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      const tick = () => {
        if (typeof window.mammoth !== 'undefined') return resolve();
        if (Date.now() - start > timeoutMs) return reject(new Error('Document renderer not available'));
        setTimeout(tick, 100);
      };
      tick();
    });
  }

  function extractYoutubeId(url) {
    const m = String(url || '').match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{6,})/);
    return m ? m[1] : null;
  }

  function filename(p) {
    return String(p || '').split(/[\\/]/).pop();
  }

  function formatMeta(screen) {
    const parts = [];
    parts.push(screen.type.toUpperCase());
    if (screen.hours) parts.push(screen.hours + ' hr');
    if (screen.equipment) parts.push(screen.equipment);
    return parts.join(' · ');
  }

  /* Progress / persistence */
  function progressKey() { return 'matrix-lms:progress:' + courseId; }
  function indexKey() { return 'matrix-lms:lastIndex:' + courseId; }

  function loadProgress() {
    try { return JSON.parse(localStorage.getItem(progressKey()) || '{}'); }
    catch (_) { return {}; }
  }
  function saveProgress(p) {
    localStorage.setItem(progressKey(), JSON.stringify(p));
  }
  function isComplete(screenId) {
    const p = loadProgress();
    return Boolean(p[screenId]);
  }
  function setComplete(screenId, value) {
    const p = loadProgress();
    const wasComplete = Boolean(p[screenId]);
    if (value) {
      if (!p[screenId]) p[screenId] = { ts: Date.now() };
    } else {
      delete p[screenId];
    }
    saveProgress(p);
    const idx = course.screens.findIndex((s) => s.id === screenId);
    const li = els.screenList.querySelector(`.screen-item[data-index="${idx}"]`);
    if (li) li.classList.toggle('completed', value);
    renderProgress();
    if (idx === currentIndex) updateCompleteButton();
    if (window.Gamify && value && !wasComplete) {
      window.Gamify.onComplete(courseId, course.screens[idx]);
    }
    /* SCORM: report completion progress to the host LMS, if any */
    if (window.MatrixSCORM && window.MatrixSCORM.isActive && window.MatrixSCORM.isActive()) {
      const completed = course.screens.filter((s) => isComplete(s.id)).length;
      window.MatrixSCORM.screenComplete(completed, course.screens.length);
      if (completed >= course.screens.length) window.MatrixSCORM.courseComplete();
    }
  }
  function toggleComplete(screenId) {
    setComplete(screenId, !isComplete(screenId));
  }
  function persistLastIndex(idx) {
    try { localStorage.setItem(indexKey(), String(idx)); } catch (_) {}
  }
  function restoreLastIndex() {
    const raw = Number(localStorage.getItem(indexKey()));
    if (Number.isFinite(raw) && raw >= 0 && raw < course.screens.length) return raw;
    return 0;
  }

  function renderProgress() {
    const p = loadProgress();
    const completed = course.screens.filter((s) => p[s.id]).length;
    const total = course.screens.length;
    const pct = total ? Math.round((completed / total) * 100) : 0;
    els.progressBar.style.width = pct + '%';
    els.progressCompleted.textContent = String(completed);
    els.progressTotal.textContent = String(total);
    els.progressPercent.textContent = pct + '%';

    if (course.certificate && course.certificate.enabled && completed === total && total > 0) {
      els.certificateCta.hidden = false;
    } else {
      els.certificateCta.hidden = true;
    }
  }

  /* Utils */
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }
  function escapeAttr(s) { return escapeHtml(s); }
})();
